# HowToCode
Our CS 146 final project to create a website using HTML, CSS and JavaScript to teach people how to code.
